import React from "react";


const UseTimeout= () => {
    return (
       <div>UseTimeout</div> 
    )
};

export {UseTimeout};